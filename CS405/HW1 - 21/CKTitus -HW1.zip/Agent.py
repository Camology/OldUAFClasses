from Deck import Deck
from collections import Counter
from random import randint 

class Agent:
    def __init__(self, name, agentType):
        self.name = name
        self.hand=[]
        self.score = 0
        self.wins = 0
        self.type = agentType

    def wonGame(self):
        print("Congratuations " + self.name + ", you won! \n")
        self.wins+=1

    def printStats(self, gameNum):
        print(self.name + " has won: " +  str(self.wins) 
        + " Times, " + str((float(self.wins)/gameNum)*100) 
        + "% of the games")

    def scoreHand(self):
        self.score = 0
        ace = False
        for card in self.hand:
            if (card ==1):
                ace = True
            else:
                self.score += int(card)
        if (ace==True):
            if (self.score+11 <= 21):
                self.score+=11
            else:
                self.score+=1
        return self.score

    def printHand(self):
        for card in self.hand:
            print(card)

    def discardHand(self):
        self.hand.clear()
        
    def advancedChoice(self, opponent):
        self.scoreHand()
        ourDeck = Deck(4)
        goal = range(1,22-self.score)
        for card in self.hand:
            ourDeck.cards.remove(card)
        for card in opponent.hand:
            ourDeck.cards.remove(card)

        count = Counter(ourDeck.cards)
        pullChance = 0
        for value in goal:
            pullChance+= (float(count[value])/len(ourDeck.cards))
        return (0.5 < (pullChance))
    
    def humanMove(self): 
        self.scoreHand()
        if (self.score > 21):
            print("Busted 21, sorry")
            return False
        print("Current Hand: \n")
        self.printHand()
        print("Current Score: " + str(self.score) + "\n")
        choice = input("Y to hit: ")
        if (choice == "Y" or choice == 'y'):
            return True
        else: return False

    def makeMove(self, opponent):
        if (self.type == 'Human'):
            playerChoice = self.humanMove()
        elif (self.type == 'Advanced'):
            playerChoice = self.advancedChoice(opponent)
        else:
            playerChoice = randint(0,1)     
        return playerChoice