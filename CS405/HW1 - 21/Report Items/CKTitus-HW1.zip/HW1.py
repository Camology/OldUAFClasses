""" 
    21 played by an AI and the dealer
    Cameron K Titus
    Rules
    A [1 or 11]
    Face value = value
    JQK = 10
    Suit does not matter

    Deal 2 cards first, dealer shows first card
    3 Player choices
    Hit - Draw another card
    Stand - Stop current total
    Surrender 

    Dealer plays:
    Dealer draws until total of 17 or more, cannot stop drawing

    Winner:
    Players win if dealer busts and AI does not, otherwise whomever is closest to 21. If tie neither win
"""

from random import randint, shuffle
from collections import Counter
import time


class Deck:
    def __init__(self, numberSuits):
        self.cards =[]
        iterator=0
        for iterator in range(numberSuits):
            self.cards += [v for v in range(1,10)] 
            self.cards += [10,10,10,10]
            iterator+=1
        shuffle(self.cards)
    
    def dealCard(self):
        card = self.cards.pop()
        return card


class Agent:
    def __init__(self, name, agentType):
        self.name = name
        self.hand=[]
        self.score = 0
        self.wins = 0
        self.type = agentType

    def wonGame(self):
        self.wins+=1

    def printStats(self, gameNum):
        print(self.name + " has won: " +  str(self.wins) 
        + " Times, " + str((float(self.wins)/gameNum)*100) 
        + "% of the games")

    def scoreHand(self):
        self.score = 0
        ace = False
        for card in self.hand:
            if (card ==1):
                ace = True
            else:
                self.score += int(card)
        if (ace==True):
            if (self.score+11 <= 21):
                self.score+=11
            else:
                self.score+=1
        return self.score

    def printHand(self):
        for card in self.hand:
            print(card)

    def discardHand(self):
        self.hand.clear()
        
    def advancedChoice(self, opponent):
        self.scoreHand()
        ourDeck = Deck(4)
        goal = range(1,22-self.score)
        for card in self.hand:
            ourDeck.cards.remove(card)
        for card in opponent.hand:
            ourDeck.cards.remove(card)

        count = Counter(ourDeck.cards)
        pullChance = 0
        for value in goal:
            pullChance+= (float(count[value])/len(ourDeck.cards))
        return (0.5 < (pullChance))

    def makeMove(self, opponent):
        if (self.type == 'Advanced'):
            playerChoice = self.advancedChoice(opponent)
        else:
            playerChoice = randint(0,1)     
        return playerChoice
class GameBoard:
    def __init__(self,player,dealer):
        self.player = player
        self.dealer = dealer
        self.numberTies = 0
        self.gameNumber = 0
    def newGame(self):
        #PHASE 1 (Initial draws and cleanup from last game)
        self.player.discardHand()
        self.dealer.discardHand()
        deck = Deck(4)
        while (len(self.dealer.hand) < 1):
            self.player.hand.append(deck.dealCard())
            self.player.hand.append(deck.dealCard())
            self.dealer.hand.append(deck.dealCard())

        #PHASE 2 (players turn)
        # Draw more cards or stay
        playerChoice = self.player.makeMove(self.dealer)
        while(playerChoice):
            self.player.hand.append(deck.dealCard())
            playerChoice = self.player.makeMove(self.dealer)

        #PHASE 3 (dealers turn)
        # Draw until 17 points or more
        while(self.dealer.scoreHand() < 17):
            self.dealer.hand.append(deck.dealCard())


        #END PHASE
        self.dealer.scoreHand()
        self.player.scoreHand()
        if (self.player.score > 21 and self.dealer.score > 21):
            self.numberTies+=1
        else:
            if (self.dealer.score == 21 or self.player.score > 21):
                self.dealer.wonGame()
            elif (self.player.score == 21 or self.dealer.score > 21):
                self.player.wonGame()
            else:
                self.scoreGame()

    def scoreGame(self):
        goal = 21
        playerScore = goal-self.player.score
        dealerScore = goal-self.dealer.score
        if (playerScore < dealerScore):
            self.player.wonGame()
        elif (dealerScore < playerScore):
            self.dealer.wonGame()
        else:
            #tiegame
            self.numberTies+=1
        

try:
    player = Agent(input("Enter the players name: ") or "Johnny Q", input("Enter the AI type: ") or "Random")
except ValueError:
    print("Not a valid name, default name is Johnny Q")
    player = Agent("Johnny Q", "Random")
try:
    dealer = Agent(input("Enter the dealers name: ") or "Metzgar the Brave","Dealer")
except ValueError:
    print("Not a valid dealer, default name is Metzgar the Brave")
    dealer = Agent("Metzgar the Brave", "Dealer")

table = GameBoard(player,dealer)
try:
    maxGames = int(input("Enter amount of games to run: ") or 1000)
except ValueError:
    print("Not a valid number of games, default is 1000")
    maxGames = 1000
start_Time = time.time()
while(table.gameNumber < maxGames):
    table.gameNumber+=1
    table.newGame()
player.printStats(table.gameNumber)
dealer.printStats(table.gameNumber)
print("There were " + str(table.numberTies) + " of ties. This happened " + str((float(table.numberTies)/table.gameNumber)*100) + "% of the time")
print("Total time was: " + str(time.time() - start_Time) + " sec.")